<?php
$a = 'PHP lAB 06';
?>

<html>
<head>
  <meta http-equiv="content-type" content="text/html; charset=utf-8">
  <title><?php echo $a; ?> Php !</title>
  </head>

  <body>
  	
  <h3><?php echo $a; ?></h3>
  <p>This the Task7 part(b) of LAB 06</p>
  <p><a href="http://localhost/var.php">Go to the <?php echo $a; ?></a>.</p>
</body>
</html>