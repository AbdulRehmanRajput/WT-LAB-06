<?php
$a = 20;
$b = 80;
echo "\nBefore swapping:  ". $a . ',' . $b;
echo "<br>";
list($a, $b) = array($b, $a);
echo "\nAfter swapping:  ". $a . ',' . $b."\n";
?>