<?php

$rd = getenv('DOCUMENT_ROOT');
echo $rd."\n";
echo "<br>";

echo 'Current script owner: ' . get_current_user();

?>